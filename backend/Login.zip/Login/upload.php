 <?php
// Database configuration
session_start();
$dbHost     = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName     = "phplogin";
$errors = array();
// Create database connection
$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
$statusMsg = '';
if(isset($_POST['submit'])){
    $var = $_POST['docx'];
// File upload path
$targetDir = "uploads/";
$fileName = basename($_FILES["file"]["name"]);
$targetFilePath = $targetDir . $fileName;
$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

if(isset($_POST["submit"]) && !empty($_FILES["file"]["name"])){
    // Allow certain file formats
    $allowTypes = array('pdf','doc','docx','ppt','pptx','wps','txt');
    if(in_array($fileType, $allowTypes)){
        // Upload file to server
        if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){
            // Insert image file name into database
//            $insert = $db->query("INSERT into images (file_name, uploaded_on) VALUES ('".$fileName."', NOW())");
            if($var=="one"){
             $insert = $db->query("UPDATE accounts SET `file_name`='".$fileName."' WHERE username = '".$_SESSION['name']."'" );
             $var1 =$fileName; }
            else{
             $insert = $db->query("UPDATE accounts SET `file_name2`='".$fileName."' WHERE username = '".$_SESSION['name']."'" );
            }
            
            if($insert){
                $statusMsg = "The file ".$fileName. " has been uploaded successfully.";
            }else{
                $statusMsg = "File upload failed, please try again.";
            } 
        }else{
            $statusMsg = "Sorry, there was an error uploading your file.";
        }
    }else{
//        $statusMsg = 'Sorry, only pdf, doc, docx, ppt, pptx, wps and txt files are allowed to upload.';
        array_push($errors, "Sorry, only pdf, doc, docx, ppt, pptx, wps and txt files are allowed to upload.");
    }
}else{
    $statusMsg = 'Please select a file to upload.';
}
}
// Display status message
//array_push($errors, $statusMsg);
//           if(empty($_GET['status'])){
//     header('Location:home.php?status=1');
//     exit;
//}
            
?>